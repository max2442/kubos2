import isisants
import _thread
isisants.py_k_ants_init(b"/dev/i2c-1",0x31,0x32,4,10)
isisanst.py_k_ants_arm()
def deploy(int j):
  if j==0:
    isisants.py_k_ants_deploy(ANT_1, False, 30)
  elif j==1:
    isisants.py_k_ants_deploy(ANT_2, False, 30)
 
